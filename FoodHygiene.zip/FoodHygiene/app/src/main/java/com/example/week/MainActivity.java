package com.example.week;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.StrictMode;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    TextView output;
    EditText input;
    RadioButton postcode, business;
    double lat;
    double lng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        output = findViewById(R.id.restaurant);
        StrictMode.ThreadPolicy policy  = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        String[] requiredPermissions = {
                Manifest.permission.INTERNET,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
        };

        boolean ok = true;


        for(int i = 0; i < requiredPermissions.length; i++) {

            int result = ActivityCompat.checkSelfPermission(this, requiredPermissions[i]);

            if (result != PackageManager.PERMISSION_GRANTED) {
                ok = false;
            }

        }

            if(!ok){

                ActivityCompat.requestPermissions(this, requiredPermissions,1);
                System.exit(0);

            }
            else{

                LocationManager im = (LocationManager) getSystemService(LOCATION_SERVICE);
                im.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new LocationListener() {

                    @Override
                    public void onLocationChanged(Location location) {

                        lat = location.getLatitude();
                        lng = location.getLongitude();

                        ((TextView) findViewById(R.id.lattextView)).setText(""+ lat);
                        ((TextView) findViewById(R.id.langtextView2)).setText(""+ lng);

                    }

                    @Override
                    public void onStatusChanged(String provider, int status, Bundle extras) {

                    }

                    @Override
                    public void onProviderEnabled(String provider) {

                    }

                    @Override
                    public void onProviderDisabled(String provider) {

                    }
                });
            }

        }



    public void getData(View view) throws UnsupportedEncodingException {

        input = findViewById(R.id.input);
        postcode = findViewById(R.id.buttonPostcode);
        business = findViewById(R.id.buttonLocation);

        if(postcode.isChecked()){

            String PostCodeInput = URLEncoder.encode(input.getText().toString(), StandardCharsets.UTF_8.toString());
            Hygiene client = new Hygiene(output);
            client.getRatingbyPoscode(PostCodeInput);

        }
        else if (business.isChecked()){

            String BusinessNameInput = URLEncoder.encode(input.getText().toString(), StandardCharsets.UTF_8.toString());
            Hygiene client = new Hygiene(output);
            client.getRatingByBusinessName(BusinessNameInput);

        }
        else{

            Hygiene client = new Hygiene(output);
            client.getRatingsByLocation(lat, lng);
            input.setText("");

        }

    }

}