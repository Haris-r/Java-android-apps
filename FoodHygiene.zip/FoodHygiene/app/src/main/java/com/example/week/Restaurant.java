package com.example.week;

public class Restaurant {

    private String name;
    private int hygieneRate;

    public Restaurant(){

        this.name = name;
        this.hygieneRate = hygieneRate;

    }

    public String getName(){
        return name;
    }

    public int getHygieneRate(){
        return hygieneRate;
    }

    public void setName(String name){
        this.name = name;
    }

    public void setHygieneRate(int hygieneRate){
        this.hygieneRate = hygieneRate;
    }

}
