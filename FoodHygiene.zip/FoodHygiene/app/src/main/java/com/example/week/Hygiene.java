package com.example.week;

import android.os.AsyncTask;
import android.widget.RadioButton;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

public class Hygiene {

    ArrayList<Restaurant> restaurants = new ArrayList<>();

    TextView restaurant;
    public Hygiene(TextView target) {
        super();
        this.restaurant = target;
    }

    public class AsyncTask02 extends AsyncTask<URL , Void , List<Restaurant>> {

        TextView restaurant;
        public AsyncTask02(TextView target) {
            super();
            this.restaurant = target;
        }

        @Override
        protected List<Restaurant> doInBackground(URL... urls) {

            URLConnection tc = null;

            try {

                tc = urls[0].openConnection();
                InputStreamReader isr = new InputStreamReader(tc.getInputStream());
                BufferedReader in = new BufferedReader(isr);

                String line = "" , rb= "" ,businessInfo = "";

                while ((line = in.readLine()) != null) {

                    rb = rb + line;

                }
                JSONArray ja = new JSONArray(rb);

                for (int i = 0; i < ja.length(); i ++) {

                    JSONObject jo = (JSONObject) ja.get(i);

                    Restaurant restaurant = new Restaurant();
                    restaurant.setHygieneRate(Integer.valueOf(jo.getString("RatingValue")));
                    restaurant.setName(jo.getString("BusinessName"));

                    restaurants.add(restaurant);
                }

                in.close();

            }

            catch (IOException e) {

                e.printStackTrace();

            }

            catch (JSONException e) {

                e.printStackTrace();

            }


            return restaurants;
        }

        @Override
        protected void onPostExecute(List<Restaurant> restaurants) {
            super.onPostExecute(restaurants);
            String display = "";
            for (Restaurant i: restaurants) {
                display+= "Business name:      " + i.getName() + "\n"
                        +"\n"
                        +"\n"
                        + "Rating:                       "+ i.getHygieneRate()
                        + "\n________________________________________________\n";

            }
            restaurant.setText(display);
        }
    }

    public void getRatingbyPoscode(String postcode){
        URL url = null;
        try {

            url = new URL("http://sandbox.kriswelsh.com/hygieneapi/hygiene.php?op=search_postcode&postcode="+postcode);

        }

        catch (MalformedURLException e) {

            e.printStackTrace();

        }
        new AsyncTask02(restaurant).execute(url);
    }

    public void getRatingByBusinessName(String businessName){

        URL url = null;

        try {

            url = new URL("http://sandbox.kriswelsh.com/hygieneapi/hygiene.php?op=search_name&name="+ businessName);

        }

        catch (MalformedURLException e) {

            e.printStackTrace();

        }
        new AsyncTask02(restaurant).execute(url);
    }

    public void getRatingsByLocation(double lat, double lng){

        URL url = null;

        try {
            url = new URL("http://sandbox.kriswelsh.com/hygieneapi/hygiene.php?op=search_location&lat=" + lat+ "&long=" + lng);
        }

        catch (MalformedURLException e) {

            e.printStackTrace();

        }
        new AsyncTask02(restaurant).execute(url);

    }



}