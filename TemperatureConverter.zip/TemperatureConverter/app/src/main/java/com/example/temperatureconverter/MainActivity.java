package com.example.temperatureconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    DecimalFormat roundUp = new DecimalFormat("###,###");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void convert_onclick (View v){

        EditText userinput = findViewById(R.id.editTextUserInput);

        RadioButton FtoC = findViewById(R.id.ButtonFtoC);

        RadioButton CtoF = findViewById(R.id.ButtonCtoF);

        RadioButton FtoK = findViewById(R.id.ButtonFtoK);

        RadioButton KtoF = findViewById(R.id.ButtonKtoF);

        RadioButton KtoC = findViewById(R.id.ButtonKtoC);

        RadioButton CtoK = findViewById(R.id.ButtonCtoK);

        Float input = Float.valueOf(userinput.getText () .toString());

        float output = 0;

        if (FtoK.isChecked() ) {
            output = (5.0F/9.0F)*(input - 32);
        }

        else if(CtoF.isChecked()){
            output = ((9.0F/5.0F)*input) + 32;
        }

        if(FtoK.isChecked()){
            output = (float) (((input-32)*5.0F/9.0F)+273.15);

        }
        else if(KtoF.isChecked()){
            output = (float) (input-273.15)*9/5+32;
        }

        if(KtoC.isChecked()){
            output = (float) (input-273.15);
        }

        else if(CtoK.isChecked()){
            output = (float) (input+273.15);
        }

        userinput.setText("" + roundUp.format(output));




    }
}
