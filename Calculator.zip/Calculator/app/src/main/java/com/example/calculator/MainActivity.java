package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    double num1 = 0, num2 = 0;
    char operator;
    TextView input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input = findViewById((R.id.input));
    }

    public void handlerOP(View v){

        input = this.findViewById(R.id.input);

        Button op = (Button) v;
        operator = op.getText().charAt(0);
        num1 = Double.valueOf(input.getText().toString());
        input.setText("");
        System.out.print(num1 + " " + operator);


    }

    public void handleEquals(View v){
        Button op = (Button) v;
        num2 = Double.valueOf(input.getText().toString());
        input.setText("");
        double answer=0;

        switch (operator){

            case'+':
                answer=num1 + num2;
                break;

            case'-':
                answer=num1 - num2;
                break;
            case'*':
                answer=num1 * num2;
                break;
            case'/':
                answer=num1 / num2;
                break;
        }
        input.setText("" + answer);
    }



    public void clearButton(View v){
        num1=0;
        num2=0;
        input.setText("");
    }





}
