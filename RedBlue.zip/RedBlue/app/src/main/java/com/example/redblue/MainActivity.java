package com.example.redblue;

import androidx.annotation.ColorInt;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void changeRed(View v){

        Button changeRed =(Button)findViewById(R.id.button);
        Button changeBlue =(Button)findViewById(R.id.button2);

        changeBlue.setBackgroundColor(Color.BLUE);
        changeRed.setText("Colour Changed");
        changeBlue.setText("BLUE");

        this.getWindow().getDecorView().getRootView().setBackgroundColor(Color.RED);
    }

    public void changeBlue(View v){

        Button changeRed =(Button)findViewById(R.id.button);
        Button changeBlue =(Button)findViewById(R.id.button2);

        changeBlue.setBackgroundColor(Color.RED);
        changeBlue.setText("Colour Changed");
        changeRed.setText("RED");

        this.getWindow().getDecorView().getRootView().setBackgroundColor(Color.BLUE);
    }
}
